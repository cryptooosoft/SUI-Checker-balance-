import asyncio
import multiprocessing
import random
import aiohttp
from python_socks._errors import ProxyError
from aiohttp_socks import ChainProxyConnector

headers = {
    "accept": "*/*",
    "content-type": "application/json",
    "sec-ch-ua": "\"Chromium\";v=\"122\", \"Not(A:Brand\";v=\"24\", \"Google Chrome\";v=\"122\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site"
}
async def check_request(session, address):
    url = "https://sui-mainnet.mystenlabs.com/json-rpc"
    data = {
        "jsonrpc": "2.0",
        "id": 4,
        "method": "suix_getAllBalances",
        "params": [address]
    }
    valid = False
    async with session.post(url, headers=headers, json=data) as response:
        response_data = await response.json()
        if response_data['result']:
            balance = int(response_data['result'][0]['totalBalance'])/1000000
            if int(balance) > 0:
                valid = True
                with open("good.txt", 'a+', encoding='utf-8') as f:
                    f.write(f"{address} {balance}\n")
                    f.close()
            else:
                with open("bad.txt", 'a+', encoding='utf-8') as f:
                    f.write(f"{address} 0\n")
                    f.close()

            print(address, balance)
        else:
            with open("bad.txt", 'a+', encoding='utf-8') as f:
                f.write(f"{address} 0\n")
                f.close()
            print(address, 0)
    return valid


async def main(_lines):
    f = open('proxies.txt', 'rt')
    socks = random.choice([f"socks5://{p}" for p in f.read().split("\n") if p])
    f.close()
    if not socks:
        print('proxy list empty')
        return
    connector = ChainProxyConnector.from_urls([socks])
    timeout = aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
        count = 0
        count_valid = 0
        for line in _lines:
            while True:
                try:
                    valid = await check_request(session, line)
                    if valid:
                        count_valid += 1
                    count += 1
                    print(f"{count}/{len(_lines)}; VALID: {count_valid}")
                    break
                except ProxyError as e:
                    print(f'Ошибка в прокси', e)
                    await asyncio.sleep(random.randint(5, 20))
                except Exception as e:
                    if not str(e).find('Attempt to decode JSON with unexpected mimetype: text/html; charset=utf-8') > -1:
                        print(e)
                    await asyncio.sleep(random.randint(5, 20))
                        

with open("wallets.txt", encoding='utf-8') as f:
    lines = [l for l in f.read().split('\n') if l]
#asyncio.run(main(lines))
def starter_main(_lines):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main(_lines))


if __name__ == "__main__":
    threads = 10
    step = len(lines) // threads if len(lines) // threads >= 1 else 1
    for i in range(0, len(lines) + step, step):
        multiprocessing.Process(target=starter_main, args=(lines[i:i + step],)).start()
